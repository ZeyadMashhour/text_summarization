		DUC 2004 Summarization Documents


Created: March 1, 2011


1. Overview

This package contains test documents and topicsets from DUC 2004
summarization tasks 1-5.

Additional DUC 2004 data are available at:
   http://duc.nist.gov/data.html

DUC 2004 task guidelines are available at:
   http://duc.nist.gov/guidelines/2004.html


2. Contents

duc2004_testdata:
  Test document sets and topicsets


3. Contact Information

For further information about the contents of this data release,
please contact:

  Hoa Dang, NIST, TAC/DUC organizer                <hoa.dang@nist.gov>
